# Overview carepath LOINC - Patient Monitoring Outcome FHIR Implementation Guide v0.1.0

## Overview carepath LOINC

This FHIR implementation content is currently under development and may be subject to significant changes. Use this information with caution, as it may not yet reflect finalized or fully validated guidance. Always verify details before relying on them for production use.

### TO-DO

| | | | | | | | | | | | |
| :--- | :--- | :--- | :--- | :--- | :--- | :--- | :--- | :--- | :--- | :--- | :--- |
| Snomed CT Code | LOINC code | Short Display | Long Description (EN) | Status | translation NL available (nl-BE) | translation FR available (fr-BE) | Fibricheck (Y/N) | MoveUp (Y/N) | Remecare (Y/N) | Byteflies (Y/N) | Abbott (Y/N) |
|   | 29463-7 | Weight | Body weight |   | No | Yes |   | Y | Y | Y |   |
|   | 8310-5 | Body temperature | Body temperature |   | No | Yes |   | Y | Y | Y |   |
|   | 39156-5 | BMI | Body mass index (BMI) [Ratio] |   | No | No |   | Y | Y |   |   |
|   | 8480-6 | BP sys | Systolic blood pressure |   | No | No |   | Y | Y | Y |   |
|   | 8462-4 | BP dias | Diastolic blood pressure |   | No | No |   | Y | Y | Y |   |
|   | 8867-4 | Heart rate | Heart rate |   | No | No |   | Y | Y | Y |   |
|   | 64008-6 | Pain severity | Pain severity [Score] [PhenX] |   | No | No |   | Y | Y |   |   |
|   | ? | ? | Weight gain (%) |   |   |   |   |   | Y |   |   |
|   | 59417-6 | SaO2 Resting % BldA PulseOx | Oxygen saturation in Arterial blood by Pulse oximetry –resting |   | No | Yes |   |   | Y | N, 59408-5 |   |
|   | 76528-9 | Breaths.spontaneous | Breath rate spontaneous |   | No | No |   | Y | Y | Y |   |
|   | ? |   | Anxiety score (Hospital Anxiety and Depression Scale) |   |   |   |   | Y | Y |   |   |
|   | ? |   | Depression score (Hospital Anxiety and Depression Scale) |   |   |   |   | Y | Y |   |   |
|   | ? |   | Breath rate resting |   |   |   |   | Y | Y |   |   |
|   | ? |   | Body weight difference (between this and last measure) |   |   |   |   |   | Y |   |   |
|   | 41950-7 | # steps 24h nRate Measured | Number of steps in 24 hour Measured |   | No | No |   | Y | Y |   |   |
|   | ? |   | Heart rate before product administration |   |   |   |   |   | Y |   |   |
|   | ? |   | Heart rate during product administration |   |   |   |   |   | Y |   |   |
|   | ? |   | Heart rate after product administration |   |   |   |   |   | Y |   |   |
|   | ? |   | Systolic blood pressure before product administration (exists for transfusion and anesthesia) |   |   |   |   |   | Y |   |   |
|   | ? |   | Systolic blood pressure during product administration (exists for transfusion and anesthesia) |   |   |   |   |   | Y |   |   |
|   | ? |   | Systolic blood pressure after product administration (exists for transfusion and anesthesia) |   |   |   |   |   | Y |   |   |
|   | ? |   | Diastolic blood pressure before product administration (exists for transfusion and anesthesia) |   |   |   |   |   | Y |   |   |
|   | ? |   | Diastolic blood pressure during product administration (exists for transfusion and anesthesia) |   |   |   |   |   | Y |   |   |
|   | ? |   | Diastolic blood pressure after product administration (exists for transfusion and anesthesia) |   |   |   |   |   | Y |   |   |
|   | 8460-8 | BP sys–stand | Systolic blood pressure–standing |   | No | No |   |   | Y |   |   |
|   | 8461-6 | BP sys–sup | Systolic blood pressure–supine |   | No | No |   |   | Y |   |   |
|   | 8454-1 | BP dias–stand | Diastolic blood pressure–standing |   | No | No |   |   | Y |   |   |
|   | 8455-8 | BP dias–sup | Diastolic blood pressure–supine |   | No | No |   |   | Y |   |   |
|   | ? |   | Body temperature before product administration |   |   |   |   |   | Y |   |   |
|   | ? |   | Body temperature during product administration |   |   |   |   |   | Y |   |   |
|   | ? |   | Body temperature after product administration |   |   |   |   |   | Y |   |   |
|   | ? |   | Morisky scale |   |   |   |   |   | Y |   |   |
|   | 67741-9 | Smoking tobacco | Smoking tobacco use duration |   | No | No |   |   | Y |   |   |
|   | ? |   | Amount of cigarettes smoked (packs) |   |   |   |   |   | Y |   |   |
|   | ? |   | Gezondheidsbeleving score controle (Bloem) |   |   |   |   |   | Y |   |   |
|   | ? |   | Gezondheidsbeleving score acceptatie (Bloem) |   |   |   |   |   | Y |   |   |
|   | 61876-9 | / | How often did you have physical energy in past 7 days [PROMIS] |   | No | No |   |   | Y |   |   |
|   | 62339-7 | / | I felt sad in the past 7 days [PROMIS.PEDS] |   | No | No |   |   | Y |   |   |
|   | 70628-3 | / | I have joint pain or muscle cramps in the past 7 days [FACIT] |   | No | No |   |   | Y |   |   |
|   | ? |   | Gedurende de laatste week, door mijn ziekte van Crohn of colitis ulcerosa, heb ik moeite gehad met persoonlijke relaties en/of moeite in de omgang met anderen. |   |   |   |   |   | Y |   |   |
|   | ? |   | Gedurende de laatste week, door mijn ziekte van Crohn of colitis ulcerosa, was ik niet tevreden over hoe mijn lichaam of sommige delen ervan eruit zagen. |   |   |   |   |   | Y |   |   |
|   | ? |   | Gedurende de laatste week, door mijn ziekte van Crohn of colitis ulcerosa, heb ik moeite gehad met school of studieactiviteiten, en/of moeite met werk of huishoudelijke taken. |   |   |   |   |   | Y |   |   |
|   | ? |   | Gedurende de laatste week, door mijn ziekte van Crohn of colitis ulcerosa, heb ik moeite gehad met de mentale en/of lichamelijke aspecten van seks. |   |   |   |   |   | Y |   |   |
|   | ? |   | Gedurende de laatste week, door mijn ziekte van Crohn of colitis ulcerosa, heb ik moeite gehad met het slapen, zoals het in slaap vallen, vaak wakker worden ’s nachts of te vroeg wakker worden ’s ochtends. |   |   |   |   |   | Y |   |   |
|   | ? |   | Gedurende de laatste week, door mijn ziekte van Crohn of colitis ulcerosa, heb ik moeite gehad om mijn stoelgang te coördineren en controleren, inclusief het (tijdig) vinden van een geschikte plaats voor ontlasting en mijzelf nadien proper te maken. |   |   |   |   |   | Y |   |   |
|   | 45720-0 |   | Stomach pain [Minimum Data Set] |   | No | No |   |   | Y |   |   |
|   | ? |   | Procentuele gewichtsafname/toename ten opzichte van referentiegewicht/alarmgewicht |   |   |   |   |   | Y |   |   |
|   | ? |   | Compliance registratie lichaamsgewicht afgelopen maand |   |   |   |   |   | Y |   |   |
|   | 44261-6 | / | Patient Health Questionnaire 9 item (PHQ-9) total score [Reported] |   | No | No |   |   | Y |   |   |
|   | ? |   | Quality of Life questionnaire EQ-5D |   |   |   |   | Y | Y |   |   |
|   | 64 different parts and codes |   | UPDRS scales |   |   |   |   |   | Y |   |   |
|   | 72106-8 | / | Total score [MMSE] |   | No | No |   |   | Y |   |   |
|   | 10230-1 |   | Left ventricular Ejection fraction |   |   |   |   |   |   |   |   |
|   |   |   |   |   |   |   |   |   |   |   |   |
|   |   | ISAR | Identification of Senior At Risk Score |   |   |   |   | Y |   |   |   |
|   |   | BAROS | Bariatric analysis and reporting outcome system Subtotal weight loss |   |   |   |   | Y |   |   |   |
|   |   | BAROS | Bariatric analysis and reporting outcome system Subtotal medical conditions |   |   |   |   | Y |   |   |   |
|   |   | BAROS | Bariatric analysis and reporting outcome system Subtotal QoL |   |   |   |   | Y |   |   |   |
|   |   | BAROS | Bariatric analysis and reporting outcome system Subtotal Complications |   |   |   |   | Y |   |   |   |
|   |   | BAROS | Bariatric analysis and reporting outcome system Total score |   |   |   |   | Y |   |   |   |
|   |   | FAOS | Foot and Ankle Outcome Score Symptoms + Stiffness score |   |   |   |   | Y |   |   |   |
|   |   | FAOS | Foot and Ankle Outcome Score Pain score |   |   |   |   | Y |   |   |   |
|   |   | FAOS | Foot and Ankle Outcome Score Function, daily living score |   |   |   |   | Y |   |   |   |
|   |   | FAOS | Foot and Ankle Outcome Score Function, sports and recreational activities score |   |   |   |   | Y |   |   |   |
|   |   | FAOS | Foot and Ankle Outcome Score Quality of life score |   |   |   |   | Y |   |   |   |
|   |   | PFP | Self-reported Physical Frailty Phenotyping  Total score |   |   |   |   | Y |   |   |   |
|   |   | OBESI-Q | kwaliteit van leven bij patiënten met morbide obesitas die een gewichtsverminderende behandeling ondergaan Totaal Eetgedrag |   |   |   |   | Y |   |   |   |
|   |   | OBESI-Q | kwaliteit van leven bij patiënten met morbide obesitas die een gewichtsverminderende behandeling ondergaan Totaal zelfbeeld |   |   |   |   | Y |   |   |   |
|   |   | CAIT | Cumberland Ankle Instability Tool Total score |   |   |   |   | Y |   |   |   |
|   |   | WRMS | Weight-Related Symptom Measure Total score |   |   |   |   | Y |   |   |   |
|   |   | WRMS | Weight-Related Symptom Measure D score (diabetes) |   |   |   |   | Y |   |   |   |
|   |   | CAT | COPD Assessment Test  CAT score |   |   |   |   | Y |   |   |   |
|   |   | SRS-22 | Scoliosis Research Society-22 Function score |   |   |   |   | Y |   |   |   |
|   |   | SRS-22 | Scoliosis Research Society-22 Pain score |   |   |   |   | Y |   |   |   |
|   |   | SRS-22 | Scoliosis Research Society-22 Self-Image score |   |   |   |   | Y |   |   |   |
|   |   | SRS-22 | Scoliosis Research Society-22 Mental health score |   |   |   |   | Y |   |   |   |
|   |   | SRS-22 | Scoliosis Research Society-22 Satisfaction score |   |   |   |   | Y |   |   |   |
|   |   | SBST | STarT Back Screening Tool Total score |   |   |   |   | Y |   |   |   |
|   |   | SBST | STarT Back Screening Tool Level of risk score |   |   |   |   | Y |   |   |   |
|   | 82323-7 | HOOS JR | Hip Disability and Osteoarthritis Outcome Score, Joint Replacement Total score |   |   |   |   | Y |   |   |   |
|   |   | MoveUP Index Knee | MoveUP Index Knee Assessment Score Total score |   |   |   |   | Y |   |   |   |
|   |   | SKV | Subjective Knee Value SKV score |   |   |   |   | Y |   |   |   |
|   |   | OES | Oxford Elbow Score Total score |   |   |   |   | Y |   |   |   |
|   |   | FJS | Forgotten Joint Score - Knee Total score |   |   |   |   | Y |   |   |   |
|   |   | QoR | Quality of recovery Score  Total score |   |   |   |   | Y |   |   |   |
|   |   | ? | COPD: Diagnosis classification Total score |   |   |   |   | Y |   |   |   |
|   |   | OMPS-Q | Örebro Musculoskeletal Pain Screening Questionnaire (short) Total score |   |   |   |   | Y |   |   |   |
|   |   | NVE | Nederlandse Vragenlijst voor Eetgedrag Emotional eating score |   |   |   |   | Y |   |   |   |
|   |   | NVE | Nederlandse Vragenlijst voor Eetgedrag Eating with diffuse emotions score |   |   |   |   | Y |   |   |   |
|   |   | NVE | Nederlandse Vragenlijst voor Eetgedrag Eating with clearly defined emotions score |   |   |   |   | Y |   |   |   |
|   |   | NVE | Nederlandse Vragenlijst voor Eetgedrag External eating score |   |   |   |   | Y |   |   |   |
|   |   | NVE | Nederlandse Vragenlijst voor Eetgedrag Restrained eating score |   |   |   |   | Y |   |   |   |
|   |   | SCL-90-R | Symptom Checklist-90-R ANG score |   |   |   |   | Y |   |   |   |
|   |   | SCL-90-R | Symptom Checklist-90-R AGO score |   |   |   |   | Y |   |   |   |
|   |   | SCL-90-R | Symptom Checklist-90-R DEP score |   |   |   |   | Y |   |   |   |
|   |   | SCL-90-R | Symptom Checklist-90-R SOM score |   |   |   |   | Y |   |   |   |
|   |   | SCL-90-R | Symptom Checklist-90-R IN score |   |   |   |   | Y |   |   |   |
|   |   | SCL-90-R | Symptom Checklist-90-R SEN score |   |   |   |   | Y |   |   |   |
|   |   | SCL-90-R | Symptom Checklist-90-R HOS score |   |   |   |   | Y |   |   |   |
|   |   | SCL-90-R | Symptom Checklist-90-R SLA score |   |   |   |   | Y |   |   |   |
|   |   | SCL-90-R | Symptom Checklist-90-R OVER score |   |   |   |   | Y |   |   |   |
|   |   | SCL-90-R | Symptom Checklist-90-R PSNEUR score |   |   |   |   | Y |   |   |   |
|   |   | BRIEF | BRIEF: Health Literacy Screening Tool Total score |   |   |   |   | Y |   |   |   |
|   |   | AUDIT | Alcohol Use Disorder Identification Test Total score |   |   |   |   | Y |   |   |   |
|   |   | POSAS | The Patient and Observer Scar Assessment Scale Total score |   |   |   |   | Y |   |   |   |
|   |   | PRWHE | Patient Rated Wrist/Hand Evaluation Pain score |   |   |   |   | Y |   |   |   |
|   |   | PRWHE | Patient Rated Wrist/Hand Evaluation Function score |   |   |   |   | Y |   |   |   |
|   |   | PRWHE | Patient Rated Wrist/Hand Evaluation Total score |   |   |   |   | Y |   |   |   |
|   |   | ESP | ESP Eating disorder Screen for Primary care Total score |   |   |   |   | Y |   |   |   |
|   |   | SVH | Subjective Hip Value Total score |   |   |   |   | Y |   |   |   |
|   |   | AOFAS | American Orthopaedic Foot and Ankle Society (AOFAS) Ankle-Hindfoot Scale Total score |   |   |   |   | Y |   |   |   |
|   | 72101-9 | KOOS | Knee Injury and Osteoarthritis Outcome Score  Symptoms score |   |   |   |   | Y |   |   |   |
|   | 72102-7 | KOOS | Knee Injury and Osteoarthritis Outcome Score  Pain score |   |   |   |   | Y |   |   |   |
|   | 72100-1 | KOOS | Knee Injury and Osteoarthritis Outcome Score  ADL score |   |   |   |   | Y |   |   |   |
|   | 72098-7 | KOOS | Knee Injury and Osteoarthritis Outcome Score  QoL score |   |   |   |   | Y |   |   |   |
|   |   | HADS | Hospital Anxiety and Depression Scale (HADS) Anxiety score |   |   |   |   | Y |   |   |   |
|   |   | HADS | Hospital Anxiety and Depression Scale (HADS) Depression score |   |   |   |   | Y |   |   |   |
|   |   | Quick DASH | Quick Disabilities of the Arm, Shoulder and Hand Total score |   |   |   |   | Y |   |   |   |
|   |   | CSI | Central sensitisation inventory (CSI) Total score |   |   |   |   | Y |   |   |   |
|   |   | HHS | Harris Hip Score Pain score |   |   |   |   | Y |   |   |   |
|   |   | HHS | Harris Hip Score Function score |   |   |   |   | Y |   |   |   |
|   |   | EORTC QLQ C30 | EORTC Core Quality of Life questionnaire Global health status/QoL (Score) |   |   |   |   | Y |   |   |   |
|   |   | EORTC QLQ C30 | EORTC Core Quality of Life questionnaire Functional scale: physical functioning (Score) |   |   |   |   | Y |   |   |   |
|   |   | EORTC QLQ C30 | EORTC Core Quality of Life questionnaire Functional scale: role functioning (Score) |   |   |   |   | Y |   |   |   |
|   |   | EORTC QLQ C30 | EORTC Core Quality of Life questionnaire Functional scale: emotional functioning (Score) |   |   |   |   | Y |   |   |   |
|   |   | EORTC QLQ C30 | EORTC Core Quality of Life questionnaire Functional scale: cognitive functioning (Score) |   |   |   |   | Y |   |   |   |
|   |   | EORTC QLQ C30 | EORTC Core Quality of Life questionnaire Functional scale: social functioning (Score) |   |   |   |   | Y |   |   |   |
|   |   | EORTC QLQ C30 | EORTC Core Quality of Life questionnaire Symptom scales/items: fatigue (Score) |   |   |   |   | Y |   |   |   |
|   |   | EORTC QLQ C30 | EORTC Core Quality of Life questionnaire Symptom scales/items: nausea & vomiting (Score) |   |   |   |   | Y |   |   |   |
|   |   | EORTC QLQ C30 | EORTC Core Quality of Life questionnaire Symptom scales/items: pain (Score) |   |   |   |   | Y |   |   |   |
|   |   | EORTC QLQ C30 | EORTC Core Quality of Life questionnaire Symptom scales/items: dyspnoea (Score) |   |   |   |   | Y |   |   |   |
|   |   | EORTC QLQ C30 | EORTC Core Quality of Life questionnaire Symptom scales/items: insomnia (Score) |   |   |   |   | Y |   |   |   |
|   |   | EORTC QLQ C30 | EORTC Core Quality of Life questionnaire Symptom scales/items: appetite loss (Score) |   |   |   |   | Y |   |   |   |
|   |   | EORTC QLQ C30 | EORTC Core Quality of Life questionnaire Symptom scales/items: constipation (Score) |   |   |   |   | Y |   |   |   |
|   |   | EORTC QLQ C30 | EORTC Core Quality of Life questionnaire Symptom scales/items: diarrhoea (Score) |   |   |   |   | Y |   |   |   |
|   |   | EORTC QLQ C30 | EORTC Core Quality of Life questionnaire Symptom scales/items: financial difficulties (Score) |   |   |   |   | Y |   |   |   |
|   |   | OKS | Oxford Knee Score Total score |   |   |   |   | Y |   |   |   |
|   |   | FTS | Food Tolerance Score Satisfaction about eating score |   |   |   |   | Y |   |   |   |
|   |   | FTS | Food Tolerance Score Tolerance score |   |   |   |   | Y |   |   |   |
|   |   | CCI | Charlson comorbidity index score Total score |   |   |   |   | Y |   |   |   |
|   |   | SF-36 | Short Form Health Survey Physical functioning score |   |   |   |   | Y |   |   |   |
|   |   | SF-36 | Short Form Health Survey Role functioning/physical score |   |   |   |   | Y |   |   |   |
|   |   | SF-36 | Short Form Health Survey Role functioning/emotional score |   |   |   |   | Y |   |   |   |
|   |   | SF-36 | Short Form Health Survey Energy/fatigue score |   |   |   |   | Y |   |   |   |
|   |   | SF-36 | Short Form Health Survey Emotional well-being score |   |   |   |   | Y |   |   |   |
|   |   | SF-36 | Short Form Health Survey Social functioning score |   |   |   |   | Y |   |   |   |
|   |   | SF-36 | Short Form Health Survey Pain SF-36 score |   |   |   |   | Y |   |   |   |
|   |   | SF-36 | Short Form Health Survey General health score |   |   |   |   | Y |   |   |   |
|   |   | SF-36 | Short Form Health Survey Total score score |   |   |   |   | Y |   |   |   |
|   |   | KOOS-12 | Knee injury and Osteoarthritis Outcome Score-12 Pain score |   |   |   |   | Y |   |   |   |
|   |   | KOOS-12 | Knee injury and Osteoarthritis Outcome Score-12 Function score |   |   |   |   | Y |   |   |   |
|   |   | KOOS-12 | Knee injury and Osteoarthritis Outcome Score-12 QoL score |   |   |   |   | Y |   |   |   |
|   |   | GAD-7 | Generalized Anxiety Disorder 7-item Total score |   |   |   |   | Y |   |   |   |
|   |   | FJS-12 | Forgotten Joint Score-12 Total score |   |   |   |   | Y |   |   |   |
|   |   | KBILD | King’s Brief Interstitial Lung Disease Questionnaire Activity score |   |   |   |   | Y |   |   |   |
|   |   | KBILD | King’s Brief Interstitial Lung Disease Questionnaire Impact score |   |   |   |   | Y |   |   |   |
|   |   | KBILD | King’s Brief Interstitial Lung Disease Questionnaire Symptome score |   |   |   |   | Y |   |   |   |
|   |   | KBILD | King’s Brief Interstitial Lung Disease Questionnaire Total score |   |   |   |   | Y |   |   |   |
|   |   | OHS | Oxford Hip Score Total score |   |   |   |   | Y |   |   |   |
|   |   | SGRQ-C | Saint- George’s Respiratory Questionnaire COPD Symptoms score |   |   |   |   | Y |   |   |   |
|   |   | SGRQ-C | Saint- George’s Respiratory Questionnaire COPD Activity score |   |   |   |   | Y |   |   |   |
|   |   | SGRQ-C | Saint- George’s Respiratory Questionnaire COPD Impacts score |   |   |   |   | Y |   |   |   |
|   |   | SGRQ-C | Saint- George’s Respiratory Questionnaire COPD Total score |   |   |   |   | Y |   |   |   |
|   |   | UCL | Utrechtse Coping Lijst ACT (Actief aanpakken, confronteren) score |   |   |   |   | Y |   |   |   |
|   |   | UCL | Utrechtse Coping Lijst PAL (Palliatieve reactie) score |   |   |   |   | Y |   |   |   |
|   |   | UCL | Utrechtse Coping Lijst VER (Vermijden, afwachten) score |   |   |   |   | Y |   |   |   |
|   |   | UCL | Utrechtse Coping Lijst SOC (Sociale steun zoeken) score |   |   |   |   | Y |   |   |   |
|   |   | UCL | Utrechtse Coping Lijst PAS (Passief reactiepatroon) score |   |   |   |   | Y |   |   |   |
|   |   | UCL | Utrechtse Coping Lijst EXP (Expressie van emoties/boosheid) score |   |   |   |   | Y |   |   |   |
|   |   | UCL | Utrechtse Coping Lijst GER (Geruststellende en troostende gedachten) score |   |   |   |   | Y |   |   |   |
|   |   | UCL | Utrechtse Coping Lijst Total score |   |   |   |   | Y |   |   |   |
|   |   | ASES | American Shoulder and Elbow Surgeons score Pain score |   |   |   |   | Y |   |   |   |
|   |   | ASES | American Shoulder and Elbow Surgeons score Function score |   |   |   |   | Y |   |   |   |
|   |   | EQ-5D | EuroQol-5 Dimension Mobility score |   |   |   |   | Y |   |   |   |
|   |   | EQ-5D | EuroQol-5 Dimension Self-care score |   |   |   |   | Y |   |   |   |
|   |   | EQ-5D | EuroQol-5 Dimension Usual activities score |   |   |   |   | Y |   |   |   |
|   |   | EQ-5D | EuroQol-5 Dimension Pain / discomfort score |   |   |   |   | Y |   |   |   |
|   |   | EQ-5D | EuroQol-5 Dimension Anxiety / depression score |   |   |   |   | Y |   |   |   |
|   |   | EQ-5D | EuroQol-5 Dimension VAS score |   |   |   |   | Y |   |   |   |
|   |   | KSS | Knee Society Score Symptoms Subscore |   |   |   |   | Y |   |   |   |
|   |   | KSS | Knee Society Score Patient Satisfaction Subscore |   |   |   |   | Y |   |   |   |
|   |   | KSS | Knee Society Score Patient Expectations Subscore |   |   |   |   | Y |   |   |   |
|   |   | KSS | Knee Society Score Functional Activities: Walking and standing Subscore |   |   |   |   | Y |   |   |   |
|   |   | KSS | Knee Society Score Functional Activities: Standard activities (ADL) Subscore |   |   |   |   | Y |   |   |   |
|   |   | KSS | Knee Society Score Functional Activities: Advanced activities Subscore |   |   |   |   | Y |   |   |   |
|   |   | KSS | Knee Society Score Functional Activities: Discretionary activities (Top 3 activities) Subscore |   |   |   |   | Y |   |   |   |
|   |   | KSS | Knee Society Score Functional activities: Total subscore |   |   |   |   | Y |   |   |   |
|   |   | GARS-4 | Groningen Activiteiten Restrictie Schaal Total score |   |   |   |   | Y |   |   |   |
|   |   | EORTC QLQ-MY20 | European Organisation for the Research and Treatment of Cancer Myeloma Module Quality of Life Questionnaire Symptom scales: disease (Score) |   |   |   |   | Y |   |   |   |
|   |   | EORTC QLQ-MY20 | European Organisation for the Research and Treatment of Cancer Myeloma Module Quality of Life Questionnaire Symptom scales: side effects (Score) |   |   |   |   | Y |   |   |   |
|   |   | EORTC QLQ-MY20 | European Organisation for the Research and Treatment of Cancer Myeloma Module Quality of Life Questionnaire Functional scales/items: body image (Score) |   |   |   |   | Y |   |   |   |
|   |   | EORTC QLQ-MY20 | European Organisation for the Research and Treatment of Cancer Myeloma Module Quality of Life Questionnaire Functional scales/items: future perspective (Score) |   |   |   |   | Y |   |   |   |
|   |   | EORTC QLQ-MY20 | European Organisation for the Research and Treatment of Cancer Myeloma Module Quality of Life Questionnaire Symptom scales: side effects MINUS HAIRLOSS (Score) |   |   |   |   | Y |   |   |   |
|   |   | CCQ | Clinical COPD Questionnaire Total score |   |   |   |   | Y |   |   |   |
|   |   | CCQ | Clinical COPD Questionnaire Symptom score |   |   |   |   | Y |   |   |   |
|   |   | CCQ | Clinical COPD Questionnaire Functional Status score |   |   |   |   | Y |   |   |   |
|   |   | CCQ | Clinical COPD Questionnaire Mental Status score |   |   |   |   | Y |   |   |   |
|   |   | ACT | Asthma Control Test Total score |   |   |   |   | Y |   |   |   |
|   |   | COMI | Core Outcome Measure Index Pain score |   |   |   |   | Y |   |   |   |
|   |   | COMI | Core Outcome Measure Index Disability score |   |   |   |   | Y |   |   |   |
|   |   | COMI | Core Outcome Measure Index Total score |   |   |   |   | Y |   |   |   |
|   |   | SSTS | Simple Shoulder Test Score Total score |   |   |   |   | Y |   |   |   |
|   |   | SEMCD | Self-Efficacy for Managing Chronic Disease 6-item Scale Total score |   |   |   |   | Y |   |   |   |
|   |   | TSK | Tampa Scale for kinesiofobia  Total score |   |   |   |   | Y |   |   |   |
|   |   | WPAI:GH | Work Productivity and Activity Impairment Questionnaire: General Health V2.0 (WPAI:GH) Percent work time missed due to health |   |   |   |   | Y |   |   |   |
|   |   | WPAI:GH | Work Productivity and Activity Impairment Questionnaire: General Health V2.0 (WPAI:GH) Percent impairment while working due to health |   |   |   |   | Y |   |   |   |
|   |   | WPAI:GH | Work Productivity and Activity Impairment Questionnaire: General Health V2.0 (WPAI:GH) Percent overall work impairment due to health |   |   |   |   | Y |   |   |   |
|   |   | WPAI:GH | Work Productivity and Activity Impairment Questionnaire: General Health V2.0 (WPAI:GH) Percent activity impairment due to health |   |   |   |   | Y |   |   |   |
|   |   | OWLQoL | Obesity and Weight-Loss Quality-of-Life Total score |   |   |   |   | Y |   |   |   |
|   |   | mFI-5 | Modified frailty index - 5 items Total score |   |   |   |   | Y |   |   |   |
|   |   | FSS | Fatigue Severity Scale Total score |   |   |   |   | Y |   |   |   |
|   |   | AKPS | Kujala Anterior Knee Pain Scale Total score |   |   |   |   | Y |   |   |   |
|   |   | ODI | Oswestry Disabilty Index Total score |   |   |   |   | Y |   |   |   |
|   |   | NDI | Neck disability index  Total score |   |   |   |   | Y |   |   |   |
|   |   | PRTEE | PATIENT-RATED TENNIS ELBOW EVALUATION Pain score |   |   |   |   | Y |   |   |   |
|   |   | PRTEE | PATIENT-RATED TENNIS ELBOW EVALUATION Specific Activities score |   |   |   |   | Y |   |   |   |
|   |   | PRTEE | PATIENT-RATED TENNIS ELBOW EVALUATION Usual Activities score |   |   |   |   | Y |   |   |   |
|   |   | PRTEE | PATIENT-RATED TENNIS ELBOW EVALUATION Function Subscale score |   |   |   |   | Y |   |   |   |
|   |   | PRTEE | PATIENT-RATED TENNIS ELBOW EVALUATION Total Score |   |   |   |   | Y |   |   |   |
|   |   | HADS | Hospital Anxiety and Depression Scale ANGST score |   |   |   |   | Y |   |   |   |
|   |   | HADS | Hospital Anxiety and Depression Scale DEPRESSIE score |   |   |   |   | Y |   |   |   |
|   |   | FAAM | Foot and Ankle Ability Measure Total score |   |   |   |   | Y |   |   |   |
|   |   | FAAM | Foot and Ankle Ability Measure Everyday Activities score |   |   |   |   | Y |   |   |   |
|   |   | FAAM | Foot and Ankle Ability Measure Sporting activities score |   |   |   |   | Y |   |   |   |
|   |   | MoveUP Index Hip | MoveUP Index Hip Assessment score moveUP index Hip score |   |   |   |   | Y |   |   |   |
|   |   | PCS | Pain Catastrophizing Scale Ruminatie score |   |   |   |   | Y |   |   |   |
|   |   | PCS | Pain Catastrophizing Scale Magnificatie score |   |   |   |   | Y |   |   |   |
|   |   | PCS | Pain Catastrophizing Scale Hulpeloosheid score |   |   |   |   | Y |   |   |   |
|   |   | PCS | Pain Catastrophizing Scale Total score |   |   |   |   | Y |   |   |   |
|   |   | BDI | Beck Depression Inventory Total score |   |   |   |   | Y |   |   |   |
|   |   | PHQ-9 | Patient Health Questionnaire-9 Total score |   |   |   |   | Y |   |   |   |
|   |   | FES-I | Falls Efficacy Scale Total score |   |   |   |   | Y |   |   |   |
|   |   | IKDC | nternational Knee Documentation Committee Score Total score |   |   |   |   | Y |   |   |   |
|   |   | OSS | Oxford Shoulder Score Total score |   |   |   |   | Y |   |   |   |
|   |   | CMS | Constant-Murley Shoulder Outcome Score Total score |   |   |   |   | Y |   |   |   |
|   |   | mHHS | Modified Harris Hip Score Total score |   |   |   |   | Y |   |   |   |
|   |   | PRAISE | Pulmonary Rehabilitation Adapted Index of Self-Efficacy Total score |   |   |   |   | Y |   |   |   |
|   |   | FABQ | Fear Avoidence Belief Questionnaire Physical activity score |   |   |   |   | Y |   |   |   |
|   |   | FABQ | Fear Avoidence Belief Questionnaire Work score |   |   |   |   | Y |   |   |   |
|   |   | FABQ | Fear Avoidence Belief Questionnaire Total score |   |   |   |   | Y |   |   |   |
|   |   | Oswestry LBPDQ | Oswestry Low Back Pain Disability Questionnaire (NL-EN-FR-ES) Total score |   |   |   |   | Y |   |   |   |
|   | 82332-8 | KOOS-JR | Knee injury and Osteoarthritis Outcome Score for Joint Replacement  Total score |   |   |   |   | Y |   |   |   |
|   |   | UCOPD | Understanding COPD Questionnaire Total score |   |   |   |   | Y |   |   |   |
|   |   | UCOPD | Understanding COPD Questionnaire About COPD score |   |   |   |   | Y |   |   |   |
|   |   | UCOPD | Understanding COPD Questionnaire Managing Symptoms of COPD score |   |   |   |   | Y |   |   |   |
|   |   | UCOPD | Understanding COPD Questionnaire Accessing Help and Support score |   |   |   |   | Y |   |   |   |
|   |   | WORQ | Work Osteoarthritis joint-Replacement Questionnaire Total score |   |   |   |   | Y |   |   |   |
|   |   | MHQ | Michigan Hand Outcomes Questionnaire Overal LEFT Hand Function score |   |   |   |   | Y |   |   |   |
|   |   | MHQ | Michigan Hand Outcomes Questionnaire Overal RIGHT Hand Function score |   |   |   |   | Y |   |   |   |
|   |   | MHQ | Michigan Hand Outcomes Questionnaire Overal Hand Function score |   |   |   |   | Y |   |   |   |
|   |   | MHQ | Michigan Hand Outcomes Questionnaire Activities of Daily Living LEFT Hand score |   |   |   |   | Y |   |   |   |
|   |   | MHQ | Michigan Hand Outcomes Questionnaire Activities of Daily Living RIGHT Hand score |   |   |   |   | Y |   |   |   |
|   |   | MHQ | Michigan Hand Outcomes Questionnaire Activities of Daily Living BOTH Hands score |   |   |   |   | Y |   |   |   |
|   |   | MHQ | Michigan Hand Outcomes Questionnaire Activities of Daily Living Total LEFT Hand score |   |   |   |   | Y |   |   |   |
|   |   | MHQ | Michigan Hand Outcomes Questionnaire Work score |   |   |   |   | Y |   |   |   |
|   |   | MHQ | Michigan Hand Outcomes Questionnaire Pain score |   |   |   |   | Y |   |   |   |
|   |   | MHQ | Michigan Hand Outcomes Questionnaire Aesthetics LEFT Hand score |   |   |   |   | Y |   |   |   |
|   |   | MHQ | Michigan Hand Outcomes Questionnaire Aesthetics Right Hand score |   |   |   |   | Y |   |   |   |
|   |   | MHQ | Michigan Hand Outcomes Questionnaire Aesthetics Overal score |   |   |   |   | Y |   |   |   |
|   |   | MHQ | Michigan Hand Outcomes Questionnaire Satisfaction Left Hand score |   |   |   |   | Y |   |   |   |
|   |   | MHQ | Michigan Hand Outcomes Questionnaire Satisfaction Right Hand score |   |   |   |   | Y |   |   |   |
|   |   | MHQ | Michigan Hand Outcomes Questionnaire Satisfaction Overal score |   |   |   |   | Y |   |   |   |
|   |   | MHQ | Michigan Hand Outcomes Questionnaire Activities of Daily Living Total RIGHT score |   |   |   |   | Y |   |   |   |
|   |   | MHQ | Michigan Hand Outcomes Questionnaire Activities of Daily Living Total Both Hands score |   |   |   |   | Y |   |   |   |
|   |   | DLQI | Dermatology Life Quality Index Total score |   |   |   |   | Y |   |   |   |
|   |   | BSHS-B | Burn Specific Health Scale - Brief Total score |   |   |   |   | Y |   |   |   |
|   | 72096-1 | HOOS | Hip disability and Osteoarthritis Outcome Score Symptoms Subscore |   |   |   |   | Y |   |   |   |
|   | 72097-9 | HOOS | Hip disability and Osteoarthritis Outcome Score Pain Subscore |   |   |   |   | Y |   |   |   |
|   | 72095-3 | HOOS | Hip disability and Osteoarthritis Outcome Score ADL Subscore |   |   |   |   | Y |   |   |   |
|   | 72093-8 | HOOS | Hip disability and Osteoarthritis Outcome Score QOL Subscore |   |   |   |   | Y |   |   |   |
|   | 88785-1 | HOOS | Hip disability and Osteoarthritis Outcome Score Stifness score |   |   |   |   | Y |   |   |   |
|   | 72094-6 | HOOS | Hip disability and Osteoarthritis Outcome Score Physical function score |   |   |   |   | Y |   |   |   |

